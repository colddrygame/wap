<?php
revo_blog_listing_check();
?>