<?php
/**
 * Widget Style: Widget First Footer
 *
 */

$ws['search-home9'] = array(
	'before_title' => '<h3>',
	'after_title' => '</h3>',
	'before_widget' => '<div class="widget %1$s %2$s search-home9"><div class="widget-inner">',
	'after_widget' => '</div></div>',
);