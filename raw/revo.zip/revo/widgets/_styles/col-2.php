<?php

$ws['col-2'] = array(
		'before_title' => '<h3><span>',
		'after_title' => '</span></h3>',
		'before_widget' => '<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 widget %1$s %2$s"><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);