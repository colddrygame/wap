<?php
$less_variables = array(
	'color'        => '#003764',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/blue'",
);


