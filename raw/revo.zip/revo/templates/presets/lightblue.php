<?php
$less_variables = array(
	'color'        => '#2874f0',
	'a-color'      => '#2874f0',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/lightblue'",
);


