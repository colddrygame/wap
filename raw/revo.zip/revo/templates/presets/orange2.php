<?php
$less_variables = array(
	'color'        => '#feb900',
	'a-color'      => '#feb900',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/orange2'",
);

